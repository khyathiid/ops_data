"""
One-command pipeline:  python run_pipeline.py

  1. generate_raw_data.py  - create the messy raw exports (skipped if they already exist)
  2. clean_data.py         - consolidate + clean with pandas
  3. build_report.py       - run SQL queries (SQLite) and build the Excel summary report

After running, open reports/Operations_Summary_Report.xlsx.
(Formula values are calculated when the file is opened in Excel / LibreOffice.)
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

import build_report          # noqa: E402
import clean_data            # noqa: E402
import generate_raw_data     # noqa: E402


def main():
    raw = ROOT / "data" / "raw"
    if not (raw / "orders_jan_mar.csv").exists():
        print("== Step 1: generating raw data ==")
        generate_raw_data.main()
    print("\n== Step 2: cleaning data (pandas) ==")
    clean_data.main()
    print("\n== Step 3: SQL queries + Excel report ==")
    build_report.main()
    print("\nDone. Open reports/Operations_Summary_Report.xlsx")


if __name__ == "__main__":
    main()
