# Operations Data Cleaning & Reporting Pipeline

An end-to-end analytics project: **messy raw exports → clean, analysis-ready dataset → SQL analysis → automated Excel report.**

It replaces a repetitive manual reporting step with a single command.

> **Note on data:** all data is **synthetic** (generated with a fixed random seed) so the project is
> reproducible and safe to share. It mirrors the kind of problems found in real operational exports.
> It is a portfolio project, not company data.

## The problem

Operations data arrives as several exports from different periods and systems, and none of them agree:

| Problem | Example in the raw files |
|---|---|
| Different column names per file | `Order ID` / `order_id` / `OrderID` |
| Mixed date formats | `2026-02-22`, `22/02/2026`, `22-Feb-26`, `Feb 22, 2026` |
| Inconsistent text | `hyderabad `, `HYD`, `Vizag`, `Bangalore`, `DELIVERED`, `Canceled` |
| Numbers stored as text | `24 pcs`, `₹1,250.00` |
| Missing values | blank quantity, price, warehouse |
| Invalid values | negative quantities, delivery date *before* order date |
| Duplicates | exact copies **and** the same order re-exported later |

## Pipeline

```
data/raw/  (3 order exports + products + warehouses)
    │   src/clean_data.py         pandas: consolidate, standardise, impute, de-duplicate, validate
    ▼
data/processed/orders_clean.csv   one row per order, 3,200 orders
    │   src/run_sql.py            SQLite: joins, GROUP BY, aggregates, HAVING
    ▼
reports/sql_results/*.csv         6 query outputs
    │   src/build_report.py       openpyxl: live formulas, charts, reconciliation
    ▼
reports/Operations_Summary_Report.xlsx
```

## Run it

```bash
pip install -r requirements.txt
python run_pipeline.py
```

Then open `reports/Operations_Summary_Report.xlsx` (formulas calculate when opened in Excel/LibreOffice).
Individual steps can also be run on their own: `python src/clean_data.py`, `python src/run_sql.py`, `python src/build_report.py`.

## What each part shows

**Cleaning (`src/clean_data.py`)**
- Consolidates 3 files (CSV, CSV, Excel) with different schemas: 3,684 raw rows → 3,200 clean orders.
- Explicit date-format parser instead of guessing, so `dd/mm/yyyy` is never misread as `mm/dd`.
- Duplicate handling in two stages: exact duplicates dropped, then re-exported orders collapsed
  (latest export wins, blanks filled from earlier copies).
- Imputation with rules that are documented and **flagged** (`qty_imputed`, `price_imputed`):
  missing quantity → product median, missing price → product list price.
- Hard `validate()` checks: the pipeline fails loudly if duplicates, nulls or negative values remain.
- Every decision is counted in `data_quality_log.csv`.

**SQL (`sql/queries.sql`)**
- Monthly summary (`GROUP BY`, conditional aggregation, `NULLIF` to avoid divide-by-zero)
- Warehouse performance (`LEFT JOIN` to keep unknown-warehouse rows)
- Top products with margin (`JOIN`, `ORDER BY ... LIMIT`)
- Category × state (3-table `JOIN`)
- Slowest delivery lanes (`HAVING` to filter small groups)
- Data quality by source file

**Report (`Operations_Summary_Report.xlsx`)**
- KPI, monthly, warehouse and category tables are **live formulas** over the cleaned data sheet.
- Charts for monthly revenue, on-time delivery trend, and on-time % by warehouse.
- Reconciliation checks: raw rows → clean rows, and Excel revenue = SQL revenue.

## Key findings from the data

1. Revenue grew **45%** from Jan to Jun; order volume up 50%, average order value flat, so growth is volume-driven.
2. **Visakhapatnam** is the delivery bottleneck: **59.6% on-time** vs 85–97% elsewhere, and all 5 product categories
   there average above the 5-day SLA.
3. Safety Gear is the largest category (36% of revenue); the top 3 products are 37% of revenue.
4. 6.1% of orders needed an imputed value or a cleared delivery date; all are flagged in the data.

## Assumptions

- Dates in slash format are `dd/mm/yyyy` (Indian convention).
- On-time = delivered within 5 days of order (SLA constant in `clean_data.py`).
- Cancelled orders count as ₹0 revenue.
- Orders with a blank warehouse are kept and labelled `Unknown` rather than dropped.

## Project structure

```
ops-data-pipeline/
├── run_pipeline.py
├── requirements.txt
├── src/
│   ├── generate_raw_data.py   synthetic messy data
│   ├── clean_data.py          pandas cleaning
│   ├── run_sql.py             SQLite loader + query runner
│   └── build_report.py        Excel report
├── sql/queries.sql
├── data/{raw,processed}/
└── reports/
```
