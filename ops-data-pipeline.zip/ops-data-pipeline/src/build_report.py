"""
Build the Excel summary report that replaces the repetitive manual reporting step.

Design principles
  * KPI, monthly, warehouse and category tables are live Excel formulas over the
    'Cleaned_Data' sheet - refresh the data and the report recalculates.
  * Top-product table comes straight from the SQL query (values, source noted).
  * A reconciliation block proves the numbers tie out (raw rows -> clean rows,
    Excel revenue vs SQL revenue).

Run:  python src/build_report.py      (after clean_data.py and run_sql.py)
"""
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

import run_sql
from clean_data import SLA_DAYS

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
OUT = ROOT / "reports" / "Operations_Summary_Report.xlsx"

FONT = "Arial"
NAVY, LIGHT, GREY = "1F3864", "D9E2F3", "F2F2F2"
f_base = Font(name=FONT, size=10)
f_bold = Font(name=FONT, size=10, bold=True)
f_head = Font(name=FONT, size=10, bold=True, color="FFFFFF")
f_title = Font(name=FONT, size=16, bold=True, color=NAVY)
f_sub = Font(name=FONT, size=10, italic=True, color="595959")
f_sec = Font(name=FONT, size=12, bold=True, color=NAVY)
fill_head = PatternFill("solid", fgColor=NAVY)
fill_light = PatternFill("solid", fgColor=LIGHT)
fill_grey = PatternFill("solid", fgColor=GREY)
thin = Side(style="thin", color="BFBFBF")
box = Border(left=thin, right=thin, top=thin, bottom=thin)

INR = '\u20b9#,##0'
NUM = '#,##0'
DEC1 = '0.0'
PCT = '0.0%'
MON = 'mmm yyyy'
DATE = 'yyyy-mm-dd'


# ---------------------------------------------------------------- helpers
def style_range(ws, cell_range, font=None, fill=None, fmt=None, align=None, border=None):
    for row in ws[cell_range]:
        for c in row:
            if font: c.font = font
            if fill: c.fill = fill
            if fmt: c.number_format = fmt
            if align: c.alignment = align
            if border: c.border = border


def header_row(ws, row, labels, col=1):
    for i, lab in enumerate(labels):
        c = ws.cell(row=row, column=col + i, value=lab)
        c.font, c.fill, c.border = f_head, fill_head, box
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[row].height = 30


def set_widths(ws, widths):
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w


def lakh(x):
    return f"\u20b9{x / 1e5:,.1f} lakh"


# ---------------------------------------------------------------- data sheet
DATA_COLS = [  # (header, dataframe column, width, number format)
    ("Order ID", "order_id", 12, None),
    ("Order Date", "order_date", 12, DATE),
    ("Order Month", "order_month_dt", 12, MON),
    ("Warehouse", "warehouse", 15, None),
    ("Category", "category", 16, None),
    ("Product", "product_name", 26, None),
    ("Quantity", "quantity", 10, NUM),
    ("Unit Price (\u20b9)", "unit_price", 12, '#,##0.00'),
    ("Status", "status", 12, None),
    ("Delivery Date", "delivery_date", 13, DATE),
    ("Lead Time (days)", "lead_time_days", 11, '0'),
    ("On Time (1/0)", "on_time", 10, '0'),
    ("Revenue (\u20b9)", "revenue", 14, '#,##0.00'),
    ("Gross Margin (\u20b9)", "gross_margin", 14, '#,##0.00'),
    ("Qty Imputed", "qty_imputed", 9, '0'),
    ("Price Imputed", "price_imputed", 9, '0'),
    ("Bad Delivery Date", "delivery_date_invalid", 10, '0'),
]
COL = {h: get_column_letter(i) for i, (h, *_rest) in enumerate(DATA_COLS, start=1)}


def write_data_sheet(wb, df):
    ws = wb.create_sheet("Cleaned_Data")
    df = df.copy()
    for c in ["order_date", "delivery_date"]:
        df[c] = pd.to_datetime(df[c])
    df["order_month_dt"] = df["order_date"].dt.to_period("M").dt.to_timestamp()
    for c in ["qty_imputed", "price_imputed", "delivery_date_invalid"]:
        df[c] = df[c].astype(int)

    header_row(ws, 1, [h for h, *_ in DATA_COLS])
    for r, rec in enumerate(df.itertuples(index=False), start=2):
        row = rec._asdict()
        for cidx, (h, key, w, fmt) in enumerate(DATA_COLS, start=1):
            v = row[key]
            if pd.isna(v):
                v = None
            elif isinstance(v, pd.Timestamp):
                v = v.to_pydatetime()
            cell = ws.cell(row=r, column=cidx, value=v)
            cell.font = f_base
            if fmt:
                cell.number_format = fmt
    set_widths(ws, [w for _, _, w, _ in DATA_COLS])
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(DATA_COLS))}{len(df) + 1}"
    return ws, len(df) + 1


def rng(header, last):
    """Absolute range on Cleaned_Data for a column header, e.g. Cleaned_Data!$M$2:$M$3201"""
    c = COL[header]
    return f"Cleaned_Data!${c}$2:${c}${last}"


# ---------------------------------------------------------------- report
def build(df, sql, log):
    wb = Workbook()
    wb.remove(wb.active)
    ws_sum = wb.create_sheet("Summary")
    ws_wh = wb.create_sheet("By_Warehouse")
    ws_cat = wb.create_sheet("By_Category")
    ws_top = wb.create_sheet("Top_Products")
    ws_dq = wb.create_sheet("Data_Quality")
    ws_data, last = write_data_sheet(wb, df)

    R = lambda h: rng(h, last)  # noqa: E731

    # ============================== Summary ==============================
    ws = ws_sum
    ws.sheet_view.showGridLines = False
    ws["A1"], ws["A1"].font = "Operations Summary Report \u2013 H1 2026", f_title
    ws["A2"] = ("Source: 3 raw exports (CSV/Excel) cleaned with Python (pandas); metrics below are live "
                "formulas over the Cleaned_Data sheet. Synthetic practice data.")
    ws["A2"].font = f_sub

    ws["A4"], ws["A4"].font = "Key metrics", f_sec
    header_row(ws, 5, ["Metric", "Value", "Definition"])
    ws.merge_cells("C5:H5")
    kpis = [
        ("Total orders", f"=COUNTA({R('Order ID')})", NUM, "All unique orders after de-duplication"),
        ("Active orders (not cancelled)", f'=COUNTIF({R("Status")},"<>Cancelled")', NUM,
         "Orders excluding cancelled"),
        ("Total revenue (\u20b9)", f"=SUM({R('Revenue (\u20b9)')})", INR, "Quantity \u00d7 unit price, cancelled = 0"),
        ("Average order value (\u20b9)", "=IFERROR(B8/B7,0)", INR, "Revenue \u00f7 active orders"),
        ("Gross margin %", f"=IFERROR(SUM({R('Gross Margin (\u20b9)')})/B8,0)", PCT,
         "(Price \u2212 unit cost) \u00d7 quantity \u00f7 revenue"),
        ("Cancellation rate", f'=IFERROR(COUNTIF({R("Status")},"Cancelled")/B6,0)', PCT,
         "Cancelled \u00f7 total orders"),
        ("Avg delivery lead time (days)", f"=IFERROR(AVERAGE({R('Lead Time (days)')}),0)", '0.00',
         "Order date to delivery date (delivered orders with valid dates)"),
        ("On-time delivery rate", f'=IFERROR(SUM({R("On Time (1/0)")})/COUNT({R("On Time (1/0)")}),0)', PCT,
         "Share of delivered orders with lead time \u2264 5 days (SLA)"),
    ]
    for i, (label, formula, fmt, note) in enumerate(kpis, start=6):
        ws.cell(row=i, column=1, value=label).font = f_bold
        v = ws.cell(row=i, column=2, value=formula)
        v.number_format, v.font = fmt, f_base
        ws.cell(row=i, column=3, value=note).font = f_sub
        for c in range(1, 9):
            ws.cell(row=i, column=c).border = box
        ws.merge_cells(start_row=i, start_column=3, end_row=i, end_column=8)
        ws.cell(row=i, column=1).fill = fill_light

    # ---- monthly trend
    ws["A16"], ws["A16"].font = "Monthly trend", f_sec
    header_row(ws, 17, ["Month", "Orders", "Cancelled", "Revenue (\u20b9)", "MoM growth",
                        "Avg order value (\u20b9)", "Avg lead time (days)", "On-time %"])
    months = sorted(pd.to_datetime(df["order_date"]).dt.to_period("M").dt.to_timestamp().unique())
    first = 18
    for i, m in enumerate(months):
        r = first + i
        ws.cell(row=r, column=1, value=pd.Timestamp(m).to_pydatetime()).number_format = MON
        ws.cell(row=r, column=2, value=f"=COUNTIF({R('Order Month')},$A{r})").number_format = NUM
        ws.cell(row=r, column=3, value=f'=COUNTIFS({R("Order Month")},$A{r},{R("Status")},"Cancelled")').number_format = NUM
        ws.cell(row=r, column=4, value=f"=SUMIFS({R('Revenue (\u20b9)')},{R('Order Month')},$A{r})").number_format = INR
        ws.cell(row=r, column=5, value=("n/a" if i == 0 else f"=IFERROR(D{r}/D{r - 1}-1,0)")).number_format = PCT
        ws.cell(row=r, column=6, value=f"=IFERROR(D{r}/(B{r}-C{r}),0)").number_format = INR
        ws.cell(row=r, column=7, value=f"=IFERROR(AVERAGEIFS({R('Lead Time (days)')},{R('Order Month')},$A{r}),0)").number_format = '0.00'
        ws.cell(row=r, column=8, value=(f'=IFERROR(SUMIFS({R("On Time (1/0)")},{R("Order Month")},$A{r})'
                                        f'/COUNTIFS({R("Order Month")},$A{r},{R("On Time (1/0)")},">=0"),0)')).number_format = PCT
    lastm = first + len(months) - 1
    tot = lastm + 1
    ws.cell(row=tot, column=1, value="Total")
    ws.cell(row=tot, column=2, value=f"=SUM(B{first}:B{lastm})").number_format = NUM
    ws.cell(row=tot, column=3, value=f"=SUM(C{first}:C{lastm})").number_format = NUM
    ws.cell(row=tot, column=4, value=f"=SUM(D{first}:D{lastm})").number_format = INR
    for r in range(first, tot + 1):
        for c in range(1, 9):
            cell = ws.cell(row=r, column=c)
            cell.font = f_bold if r == tot else f_base
            cell.border = box
            if r == tot:
                cell.fill = fill_light
            if c > 1:
                cell.alignment = Alignment(horizontal="right")
        ws.cell(row=r, column=1).alignment = Alignment(horizontal="left")

    # ---- charts
    bar = BarChart()
    bar.type, bar.title = "col", "Monthly revenue (\u20b9)"
    bar.add_data(Reference(ws, min_col=4, min_row=17, max_row=lastm), titles_from_data=True)
    bar.set_categories(Reference(ws, min_col=1, min_row=first, max_row=lastm))
    bar.x_axis.number_format, bar.x_axis.delete, bar.y_axis.delete = "mmm yy", False, False
    bar.y_axis.number_format, bar.legend = '#,##0', None
    bar.height, bar.width = 7.5, 15
    ws.add_chart(bar, "J5")

    line = LineChart()
    line.title = "On-time delivery % by month"
    line.add_data(Reference(ws, min_col=8, min_row=17, max_row=lastm), titles_from_data=True)
    line.set_categories(Reference(ws, min_col=1, min_row=first, max_row=lastm))
    line.x_axis.number_format, line.x_axis.delete, line.y_axis.delete = "mmm yy", False, False
    line.y_axis.number_format, line.y_axis.scaling.min, line.y_axis.scaling.max = '0%', 0.5, 1.0
    line.legend, line.height, line.width = None, 7.5, 15
    ws.add_chart(line, "J21")

    # ---- key findings (text written from the SQL results at build time)
    m, w = sql["monthly_summary"], sql["warehouse_performance"]
    w_known = w[w["warehouse"] != "Unknown"].sort_values("on_time_pct")
    worst, best = w_known.iloc[0], w_known.iloc[-1]
    cat_rev = df.groupby("category")["revenue"].sum().sort_values(ascending=False)
    growth = m["revenue"].iloc[-1] / m["revenue"].iloc[0] - 1
    worst_lt = df[df["warehouse"] == worst["warehouse"]].groupby("category")["lead_time_days"].mean()
    n_slow_cats, n_cats = int((worst_lt > SLA_DAYS).sum()), len(worst_lt)
    repaired = int((df["qty_imputed"] | df["price_imputed"] | df["delivery_date_invalid"]).sum())
    findings = [
        f"1. Revenue grew {growth:.0%} from {lakh(m['revenue'].iloc[0])} in Jan to {lakh(m['revenue'].iloc[-1])} in Jun, "
        f"with order volume up {m['total_orders'].iloc[-1] / m['total_orders'].iloc[0] - 1:.0%} "
        f"and average order value {m['avg_order_value'].iloc[-1] / m['avg_order_value'].iloc[0] - 1:+.0%} \u2013 growth is volume-driven.",
        f"2. {worst['warehouse']} is the delivery bottleneck: {worst['on_time_pct']:.1f}% on time and "
        f"{worst['avg_lead_time_days']:.1f}-day average lead time, versus {best['on_time_pct']:.1f}% at {best['warehouse']}. "
        f"{n_slow_cats} of {n_cats} categories shipped from {worst['warehouse']} average more than the {SLA_DAYS}-day SLA.",
        f"3. {cat_rev.index[0]} is the largest category ({lakh(cat_rev.iloc[0])}, "
        f"{cat_rev.iloc[0] / cat_rev.sum():.0%} of revenue); the top-3 products contribute "
        f"{sql['top_products']['revenue'].head(3).sum() / df['revenue'].sum():.0%} of total revenue.",
        f"4. Data quality: {repaired} of {len(df):,} orders ({repaired / len(df):.1%}) had a missing value imputed or an invalid delivery date cleared "
        f"(flagged in Cleaned_Data); see the Data_Quality sheet for the full audit trail.",
    ]
    fr = tot + 3
    ws.cell(row=fr - 1, column=1, value="Key findings (as of this data build)").font = f_sec
    for i, t in enumerate(findings):
        c = ws.cell(row=fr + i, column=1, value=t)
        c.font, c.alignment = f_base, Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=fr + i, start_column=1, end_row=fr + i, end_column=8)
        ws.row_dimensions[fr + i].height = 42
    set_widths(ws, [30, 14, 14, 18, 13, 18, 16, 12, 3])

    # ============================== By_Warehouse ==============================
    ws = ws_wh
    ws.sheet_view.showGridLines = False
    ws["A1"], ws["A1"].font = "Performance by warehouse", f_title
    ws["A2"] = "Formulas over Cleaned_Data. 'Unknown' = orders whose warehouse field was blank in the raw export."
    ws["A2"].font = f_sub
    header_row(ws, 4, ["Warehouse", "State", "Orders", "Revenue (\u20b9)", "Revenue share",
                       "Avg lead time (days)", "On-time %", "Cancel rate"])
    states = dict(zip(pd.read_csv(PROCESSED / "warehouses_clean.csv")["warehouse_name"],
                      pd.read_csv(PROCESSED / "warehouses_clean.csv")["state"]))
    wh_order = list(sql["warehouse_performance"]["warehouse"])  # revenue-sorted by SQL
    wr0 = 5
    wr1 = wr0 + len(wh_order) - 1
    for i, name in enumerate(wh_order):
        r = wr0 + i
        ws.cell(row=r, column=1, value=name)
        ws.cell(row=r, column=2, value=states.get(name, "Unknown"))
        ws.cell(row=r, column=3, value=f"=COUNTIF({R('Warehouse')},$A{r})").number_format = NUM
        ws.cell(row=r, column=4, value=f"=SUMIFS({R('Revenue (\u20b9)')},{R('Warehouse')},$A{r})").number_format = INR
        ws.cell(row=r, column=5, value=f"=IFERROR(D{r}/SUM($D${wr0}:$D${wr1}),0)").number_format = PCT
        ws.cell(row=r, column=6, value=f"=IFERROR(AVERAGEIFS({R('Lead Time (days)')},{R('Warehouse')},$A{r}),0)").number_format = '0.00'
        ws.cell(row=r, column=7, value=(f'=IFERROR(SUMIFS({R("On Time (1/0)")},{R("Warehouse")},$A{r})'
                                        f'/COUNTIFS({R("Warehouse")},$A{r},{R("On Time (1/0)")},">=0"),0)')).number_format = PCT
        ws.cell(row=r, column=8, value=f'=IFERROR(COUNTIFS({R("Warehouse")},$A{r},{R("Status")},"Cancelled")/C{r},0)').number_format = PCT
    for r in range(wr0, wr1 + 1):
        for c in range(1, 9):
            cell = ws.cell(row=r, column=c)
            cell.font, cell.border = f_base, box
            if c > 2:
                cell.alignment = Alignment(horizontal="right")
    set_widths(ws, [18, 16, 10, 18, 13, 18, 12, 12])
    ch = BarChart()
    ch.type, ch.title = "col", "On-time delivery % by warehouse"
    ch.add_data(Reference(ws, min_col=7, min_row=4, max_row=wr1), titles_from_data=True)
    ch.set_categories(Reference(ws, min_col=1, min_row=wr0, max_row=wr1))
    ch.y_axis.number_format, ch.y_axis.scaling.min, ch.y_axis.scaling.max = '0%', 0, 1
    ch.x_axis.delete = ch.y_axis.delete = False
    ch.legend, ch.height, ch.width = None, 8, 16
    ws.add_chart(ch, f"A{wr1 + 3}")

    # ============================== By_Category ==============================
    ws = ws_cat
    ws.sheet_view.showGridLines = False
    ws["A1"], ws["A1"].font = "Performance by product category", f_title
    header_row(ws, 3, ["Category", "Orders", "Units sold", "Revenue (\u20b9)", "Gross margin (\u20b9)", "Margin %"])
    cats = list(df.groupby("category")["revenue"].sum().sort_values(ascending=False).index)
    for i, cat in enumerate(cats):
        r = 4 + i
        ws.cell(row=r, column=1, value=cat)
        ws.cell(row=r, column=2, value=f"=COUNTIF({R('Category')},$A{r})").number_format = NUM
        ws.cell(row=r, column=3, value=f'=SUMIFS({R("Quantity")},{R("Category")},$A{r},{R("Status")},"<>Cancelled")').number_format = NUM
        ws.cell(row=r, column=4, value=f"=SUMIFS({R('Revenue (\u20b9)')},{R('Category')},$A{r})").number_format = INR
        ws.cell(row=r, column=5, value=f"=SUMIFS({R('Gross Margin (\u20b9)')},{R('Category')},$A{r})").number_format = INR
        ws.cell(row=r, column=6, value=f"=IFERROR(E{r}/D{r},0)").number_format = PCT
    for r in range(4, 4 + len(cats)):
        for c in range(1, 7):
            cell = ws.cell(row=r, column=c)
            cell.font, cell.border = f_base, box
            if c > 1:
                cell.alignment = Alignment(horizontal="right")
    set_widths(ws, [20, 10, 12, 18, 18, 10])

    # ============================== Top_Products ==============================
    ws = ws_top
    ws.sheet_view.showGridLines = False
    ws["A1"], ws["A1"].font = "Top 10 products by revenue", f_title
    ws["A2"] = "Source: SQL query 'top_products' (sql/queries.sql) \u2013 JOIN orders \u2192 products, GROUP BY product. Static values from the last pipeline run."
    ws["A2"].font = f_sub
    tp = sql["top_products"]
    header_row(ws, 4, ["Product ID", "Product", "Category", "Units sold", "Revenue (\u20b9)",
                       "Gross margin (\u20b9)", "Margin %"])
    for i, rec in enumerate(tp.itertuples(index=False)):
        r = 5 + i
        vals = [rec.product_id, rec.product_name, rec.category, rec.units_sold, rec.revenue,
                rec.gross_margin, rec.margin_pct / 100]
        fmts = [None, None, None, NUM, INR, INR, PCT]
        for c, (v, f) in enumerate(zip(vals, fmts), start=1):
            cell = ws.cell(row=r, column=c, value=v)
            cell.font, cell.border = f_base, box
            if f:
                cell.number_format = f
                cell.alignment = Alignment(horizontal="right")
    set_widths(ws, [12, 28, 18, 12, 18, 18, 10])

    # ============================== Data_Quality ==============================
    ws = ws_dq
    ws.sheet_view.showGridLines = False
    ws["A1"], ws["A1"].font = "Data quality audit trail", f_title
    ws["A2"] = "Every cleaning decision made by src/clean_data.py, with the number of records affected."
    ws["A2"].font = f_sub
    header_row(ws, 4, ["Step", "Issue found", "Records affected", "Action taken"])
    issue_row = {}
    for i, rec in enumerate(log.itertuples(index=False)):
        r = 5 + i
        issue_row[rec.issue] = r
        for c, v in enumerate([rec.step, rec.issue, rec.records_affected, rec.action], start=1):
            cell = ws.cell(row=r, column=c, value=v)
            cell.font, cell.border = f_base, box
            cell.alignment = Alignment(wrap_text=True, vertical="top",
                                       horizontal="right" if c == 3 else "left")
            if c == 3:
                cell.number_format = NUM
    rr = 5 + len(log) + 2
    ws.cell(row=rr, column=1, value="Reconciliation").font = f_sec
    ref = lambda key: f"C{issue_row[key]}"  # noqa: E731
    recon = [
        ("Raw rows loaded (all files)", f"={ref('Total raw rows across all files')}"),
        ("less: exact duplicate rows", f"=-{ref('Exact duplicate rows')}"),
        ("less: re-exported copies collapsed", f"=-{ref('Same order_id across exports (re-exported / updated)')}"),
        ("less: dropped (missing id / date / orphan product)",
         f"=-({ref('Missing order_id')}+{ref('Unparseable / missing order_date')}+{ref('product_id not in product master')})"),
    ]
    for i, (lab, f) in enumerate(recon):
        ws.cell(row=rr + 1 + i, column=2, value=lab).font = f_base
        c = ws.cell(row=rr + 1 + i, column=3, value=f)
        c.number_format, c.font = '#,##0;(#,##0);-', f_base
    e = rr + 1 + len(recon)
    ws.cell(row=e, column=2, value="Expected clean orders").font = f_bold
    ws.cell(row=e, column=3, value=f"=SUM(C{rr + 1}:C{e - 1})").font = f_bold
    ws.cell(row=e + 1, column=2, value="Actual rows in Cleaned_Data").font = f_bold
    ws.cell(row=e + 1, column=3, value=f"=COUNTA({R('Order ID')})").font = f_bold
    ws.cell(row=e + 2, column=2, value="Check").font = f_bold
    ws.cell(row=e + 2, column=3, value=f'=IF(C{e}=C{e + 1},"OK","MISMATCH")').font = f_bold

    x = e + 5
    ws.cell(row=x, column=1, value="Cross-check: Excel vs SQL").font = f_sec
    ws.cell(row=x + 1, column=2, value="Total revenue \u2013 Excel formula (Summary)").font = f_base
    ws.cell(row=x + 1, column=3, value="=Summary!B8").number_format = INR
    ws.cell(row=x + 2, column=2, value="Total revenue \u2013 SQL query 'monthly_summary' (sum of months)").font = f_base
    ws.cell(row=x + 2, column=3, value=float(sql["monthly_summary"]["revenue"].sum())).number_format = INR
    ws.cell(row=x + 3, column=2, value="Check (difference < \u20b91)").font = f_bold
    ws.cell(row=x + 3, column=3, value=f'=IF(ABS(C{x + 1}-C{x + 2})<1,"OK","MISMATCH")').font = f_bold
    ws.cell(row=x + 2, column=4, value="Hardcoded from SQL output at build time (reports/sql_results/monthly_summary.csv)").font = f_sub
    for r in range(rr + 1, x + 4):
        ws.cell(row=r, column=3).alignment = Alignment(horizontal="right")
    set_widths(ws, [20, 62, 18, 62])

    for sheet in (ws_sum, ws_wh, ws_cat, ws_top, ws_dq):
        sheet.page_setup.orientation = "landscape"
        sheet.page_setup.fitToWidth, sheet.page_setup.fitToHeight = 1, 0
        sheet.sheet_properties.pageSetUpPr.fitToPage = True

    wb.save(OUT)
    print(f"Report saved: {OUT}")


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(PROCESSED / "orders_clean.csv")
    log = pd.read_csv(PROCESSED / "data_quality_log.csv")
    sql = run_sql.run_all()
    build(df, sql, log)


if __name__ == "__main__":
    main()
