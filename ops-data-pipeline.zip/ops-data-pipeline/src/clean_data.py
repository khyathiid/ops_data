"""
Consolidate and clean raw operational exports into one analysis-ready dataset.

Steps
  1. Load 3 order exports (CSV, CSV, Excel) + product and warehouse reference files
  2. Standardise column names and stack them into one table
  3. Normalise text (IDs, warehouse names, status, category)
  4. Parse numbers (quantity, unit price) and dates (4 different formats)
  5. Handle missing values, invalid values and duplicate records
  6. Add derived fields (revenue, lead time, on-time flag) and validate

Every decision is counted and written to data_quality_log.csv so the cleaning
is auditable, not a black box.

Run:  python src/clean_data.py
"""
import re
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "data" / "processed"

SLA_DAYS = 5  # a delivery is "on time" if lead time <= SLA_DAYS

DATE_FORMATS = ["%Y-%m-%d", "%d/%m/%Y", "%d-%b-%y", "%b %d, %Y"]

COLUMN_MAP = {
    # canonical name : known variants across the three exports
    "order_id": ["Order ID", "order_id", "OrderID"],
    "order_date": ["Order Date", "order_dt", "OrderDate"],
    "warehouse": ["Warehouse", "wh"],
    "product_id": ["Product ID", "product_id", "ProductID"],
    "quantity": ["Qty", "quantity", "Quantity"],
    "unit_price": ["Unit Price", "price", "UnitPrice"],
    "status": ["Status", "order_status", "OrderStatus"],
    "delivery_date": ["Delivery Date", "delivered_on", "DeliveryDate"],
}

WAREHOUSE_ALIASES = {
    "vijayawada": "Vijayawada", "vjw": "Vijayawada",
    "visakhapatnam": "Visakhapatnam", "vizag": "Visakhapatnam",
    "hyderabad": "Hyderabad", "hyd": "Hyderabad",
    "chennai": "Chennai", "madras": "Chennai",
    "bengaluru": "Bengaluru", "bangalore": "Bengaluru", "blr": "Bengaluru",
}

STATUS_MAP = {
    "delivered": "Delivered",
    "cancelled": "Cancelled", "canceled": "Cancelled",
    "in transit": "In Transit", "in-transit": "In Transit",
    "shipped": "Shipped",
    "pending": "Pending",
}

log = []  # (step, issue, records_affected, action)


def record(step, issue, n, action):
    log.append({"step": step, "issue": issue, "records_affected": int(n), "action": action})


# --------------------------------------------------------------------------
# Parsers
# --------------------------------------------------------------------------
def parse_date(x):
    """Parse the 4 date formats seen in the exports; real Excel dates pass through."""
    if x is None or (isinstance(x, float) and np.isnan(x)) or pd.isna(x):
        return pd.NaT
    if isinstance(x, (pd.Timestamp, datetime)):
        return pd.Timestamp(x).normalize()
    s = str(x).strip()
    if not s:
        return pd.NaT
    for fmt in DATE_FORMATS:
        try:
            return pd.Timestamp(datetime.strptime(s, fmt))
        except ValueError:
            continue
    return pd.NaT


def parse_number(x):
    """'\u20b91,250.00' -> 1250.0 ; '24 pcs' -> 24.0 ; '' / None -> NaN."""
    if x is None or pd.isna(x):
        return np.nan
    if isinstance(x, (int, float, np.number)):
        return float(x)
    s = re.sub(r"[^0-9.\-]", "", str(x))
    try:
        return float(s)
    except ValueError:
        return np.nan


# --------------------------------------------------------------------------
# Load
# --------------------------------------------------------------------------
def standardise_columns(df):
    lookup = {v: k for k, vs in COLUMN_MAP.items() for v in vs}
    return df.rename(columns=lookup)[list(COLUMN_MAP)]


def load_orders():
    files = [
        ("orders_jan_mar.csv", pd.read_csv),
        ("orders_apr_jun.csv", pd.read_csv),
        ("orders_jun_reexport.xlsx", pd.read_excel),  # latest export -> highest priority
    ]
    frames = []
    for priority, (name, reader) in enumerate(files):
        df = standardise_columns(reader(RAW / name, dtype=object))
        df["source_file"], df["source_priority"] = name, priority
        frames.append(df)
        record("1. Load", f"Rows read from {name}", len(df), "Loaded and column names standardised")
    combined = pd.concat(frames, ignore_index=True)
    record("1. Load", "Total raw rows across all files", len(combined), "Consolidated into one table")
    return combined


def load_products():
    p = pd.read_excel(RAW / "products.xlsx", sheet_name="Products")
    p.columns = ["product_id", "product_name", "category", "unit_cost", "list_price"]
    p["product_id"] = p["product_id"].str.strip().str.upper()
    p["product_name"] = p["product_name"].str.strip()
    p["category"] = p["category"].str.strip().str.title()
    before = len(p)
    p = p.drop_duplicates("product_id")
    record("2. Reference data", "Duplicate product master rows", before - len(p), "Dropped duplicates")
    return p


def load_warehouses():
    return pd.read_csv(RAW / "warehouses.csv")


# --------------------------------------------------------------------------
# Clean
# --------------------------------------------------------------------------
def clean_orders(df, products):
    df = df.copy()

    # --- text normalisation ------------------------------------------------
    df["order_id"] = df["order_id"].astype("string").str.strip().str.upper()
    df["product_id"] = df["product_id"].astype("string").str.strip().str.upper()
    n_missing_id = df["order_id"].isna().sum()
    df = df[df["order_id"].notna()]
    record("3. Text", "Missing order_id", n_missing_id, "Dropped (cannot identify record)")

    raw_wh_orig = df["warehouse"].astype("string")
    raw_wh = raw_wh_orig.str.strip().str.lower()
    df["warehouse"] = raw_wh.map(WAREHOUSE_ALIASES)
    unmapped = df["warehouse"].isna() & raw_wh.notna()
    record("3. Text", "Unrecognised warehouse names", unmapped.sum(), "Set to 'Unknown'")
    n_missing_wh = (df["warehouse"].isna() & ~unmapped).sum()
    record("3. Text", "Missing warehouse", n_missing_wh, "Set to 'Unknown'")
    n_variant_wh = (df["warehouse"].notna() & (df["warehouse"] != raw_wh_orig)).sum()
    record("3. Text", "Warehouse names with variant spelling/case/alias", n_variant_wh,
           "Mapped to canonical name (e.g. Vizag -> Visakhapatnam)")
    df["warehouse"] = df["warehouse"].fillna("Unknown")

    raw_status = df["status"].astype("string").str.strip().str.lower()
    df["status"] = raw_status.map(STATUS_MAP)
    record("3. Text", "Unrecognised or missing status", df["status"].isna().sum(), "Set to 'Pending'")
    df["status"] = df["status"].fillna("Pending")

    # --- numbers -----------------------------------------------------------
    qty_raw, price_raw = df["quantity"], df["unit_price"]
    df["quantity"] = qty_raw.map(parse_number)
    df["unit_price"] = price_raw.map(parse_number)
    record("4. Numbers", "Quantity stored as text (e.g. '24 pcs')",
           qty_raw.map(lambda v: isinstance(v, str) and not v.strip().lstrip("-").isdigit()
                       and pd.notna(v)).sum(), "Extracted numeric value")
    record("4. Numbers", "Unit price stored with currency symbol / commas",
           price_raw.map(lambda v: isinstance(v, str) and bool(re.search(r"[^0-9.]", v))).sum(),
           "Stripped symbols, converted to float")

    # --- dates -------------------------------------------------------------
    df["order_date"] = df["order_date"].map(parse_date)
    df["delivery_date"] = df["delivery_date"].map(parse_date)
    n_bad_date = df["order_date"].isna().sum()
    df = df[df["order_date"].notna()]
    record("5. Dates", "4 different date formats parsed to one ISO date", len(df), "Parsed with explicit format list")
    record("5. Dates", "Unparseable / missing order_date", n_bad_date, "Dropped")

    # --- duplicates --------------------------------------------------------
    before = len(df)
    df = df.sort_values(["source_priority"], kind="stable")
    exact = df.duplicated(subset=["order_id", "order_date", "warehouse", "product_id",
                                  "quantity", "unit_price", "status", "delivery_date"], keep="last")
    record("6. Duplicates", "Exact duplicate rows", exact.sum(), "Dropped")
    df = df[~exact]

    # Remaining repeats of an order_id come from re-exports of the same order.
    # Keep the latest export and fill any blanks from earlier copies (coalesce).
    n_repeat = len(df) - df["order_id"].nunique()
    record("6. Duplicates", "Same order_id across exports (re-exported / updated)", n_repeat,
           "Collapsed to one row: latest export wins, blanks filled from earlier copies")
    df = df.groupby("order_id", as_index=False, sort=False).last()  # last non-null per column
    df["_dup_removed"] = before - len(df)

    # --- validate product ids ---------------------------------------------
    orphan = ~df["product_id"].isin(products["product_id"])
    record("7. Integrity", "product_id not in product master", orphan.sum(), "Dropped")
    df = df[~orphan]
    df = df.merge(products[["product_id", "product_name", "category", "unit_cost", "list_price"]],
                  on="product_id", how="left")

    # --- missing / invalid values -----------------------------------------
    neg = df["quantity"] < 0
    record("7. Integrity", "Negative quantity (sign error)", neg.sum(), "Converted to absolute value, flagged")
    df.loc[neg, "quantity"] = df.loc[neg, "quantity"].abs()

    df["qty_imputed"] = df["quantity"].isna()
    median_qty = df.groupby("product_id")["quantity"].transform("median")
    df["quantity"] = df["quantity"].fillna(median_qty).round().astype(int)
    record("7. Integrity", "Missing quantity", df["qty_imputed"].sum(),
           "Filled with product median quantity, flagged qty_imputed")

    df["price_imputed"] = df["unit_price"].isna()
    df["unit_price"] = df["unit_price"].fillna(df["list_price"]).round(2)
    record("7. Integrity", "Missing unit price", df["price_imputed"].sum(),
           "Filled with product list price, flagged price_imputed")

    bad_delivery = df["delivery_date"].notna() & (df["delivery_date"] < df["order_date"])
    record("7. Integrity", "Delivery date earlier than order date", bad_delivery.sum(),
           "Delivery date cleared, flagged; excluded from lead-time metrics")
    df["delivery_date_invalid"] = bad_delivery
    df.loc[bad_delivery, "delivery_date"] = pd.NaT

    no_date = (df["status"] == "Delivered") & df["delivery_date"].isna()
    record("7. Integrity", "Status 'Delivered' but no usable delivery date", no_date.sum(),
           "Kept; excluded from lead-time / on-time metrics")

    # --- derived fields ----------------------------------------------------
    df["order_month"] = df["order_date"].dt.strftime("%Y-%m")
    df["lead_time_days"] = (df["delivery_date"] - df["order_date"]).dt.days
    df["on_time"] = np.where(df["lead_time_days"].notna(),
                             (df["lead_time_days"] <= SLA_DAYS).astype(float), np.nan)
    df["revenue"] = np.where(df["status"] == "Cancelled", 0.0,
                             (df["quantity"] * df["unit_price"]).round(2))
    df["gross_margin"] = np.where(df["status"] == "Cancelled", 0.0,
                                  (df["quantity"] * (df["unit_price"] - df["unit_cost"])).round(2))

    cols = ["order_id", "order_date", "order_month", "warehouse", "product_id", "product_name",
            "category", "quantity", "unit_price", "status", "delivery_date", "lead_time_days",
            "on_time", "revenue", "gross_margin", "qty_imputed", "price_imputed",
            "delivery_date_invalid", "source_file"]
    df = df[cols].sort_values(["order_date", "order_id"]).reset_index(drop=True)
    record("8. Output", "Final clean orders", len(df), "One row per order, analysis-ready")
    return df


def validate(df):
    """Hard checks - the pipeline fails loudly if the output is not trustworthy."""
    assert df["order_id"].is_unique, "duplicate order_id remain"
    assert df[["order_date", "warehouse", "product_id", "quantity", "unit_price", "status"]] \
        .notna().all().all(), "nulls remain in required columns"
    assert (df["quantity"] > 0).all(), "non-positive quantity remains"
    assert (df["lead_time_days"].dropna() >= 0).all(), "negative lead time remains"
    assert set(df["status"]) <= set(STATUS_MAP.values()), "unexpected status label"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    products, warehouses = load_products(), load_warehouses()
    orders = clean_orders(load_orders(), products)
    validate(orders)

    orders.to_csv(OUT / "orders_clean.csv", index=False)
    products.to_csv(OUT / "products_clean.csv", index=False)
    warehouses.to_csv(OUT / "warehouses_clean.csv", index=False)
    quality_log = pd.DataFrame(log).sort_values("step", kind="stable")
    quality_log.to_csv(OUT / "data_quality_log.csv", index=False)

    print(quality_log.to_string(index=False))
    print(f"\nClean dataset: {len(orders):,} orders -> {OUT / 'orders_clean.csv'}")


if __name__ == "__main__":
    main()
