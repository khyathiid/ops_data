"""
Generate realistic-but-messy raw operational data (synthetic).

Simulates what a team typically receives: several exports from different
systems/periods with different column names, mixed date formats, inconsistent
text, missing values and duplicated records.

All data is synthetic and seeded, so the pipeline is fully reproducible.
Run:  python src/generate_raw_data.py
"""
import random
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

SEED = 42
N_ORDERS = 3200
RAW_DIR = Path(__file__).resolve().parents[1] / "data" / "raw"

random.seed(SEED)
rng = np.random.default_rng(SEED)

# --------------------------------------------------------------------------
# Reference data
# --------------------------------------------------------------------------
WAREHOUSES = [
    ("W01", "Vijayawada", "Andhra Pradesh"),
    ("W02", "Visakhapatnam", "Andhra Pradesh"),
    ("W03", "Hyderabad", "Telangana"),
    ("W04", "Chennai", "Tamil Nadu"),
    ("W05", "Bengaluru", "Karnataka"),
]
# How each warehouse name shows up in messy exports
WAREHOUSE_ALIASES = {
    "Vijayawada": ["Vijayawada", "vijayawada", "VIJAYAWADA", "Vijayawada ", "Vjw"],
    "Visakhapatnam": ["Visakhapatnam", "Vizag", "vizag", "VISAKHAPATNAM"],
    "Hyderabad": ["Hyderabad", "hyderabad ", "HYD", "Hyd"],
    "Chennai": ["Chennai", "CHENNAI", "chennai", "Madras"],
    "Bengaluru": ["Bengaluru", "Bangalore", "bangalore", "BLR"],
}
WAREHOUSE_WEIGHTS = [0.24, 0.16, 0.24, 0.18, 0.18]
# Mean delivery lead time (days) by warehouse - Visakhapatnam is the slow one
LEAD_TIME_MEAN = {"Vijayawada": 3.0, "Visakhapatnam": 5.2, "Hyderabad": 3.4,
                  "Chennai": 4.0, "Bengaluru": 3.6}

# product_id, name, category, unit_cost, list_price, typical_qty
PRODUCTS = [
    ("P001", "Corrugated Box (Large)", "Packaging", 38, 55, 120),
    ("P002", "Bubble Wrap Roll", "Packaging", 210, 295, 25),
    ("P003", "Packing Tape (Pack of 6)", "Packaging", 150, 220, 40),
    ("P004", "Stretch Film", "Packaging", 330, 460, 20),
    ("P005", "Barcode Scanner", "Electronics", 2600, 3450, 4),
    ("P006", "Thermal Label Printer", "Electronics", 8200, 10900, 2),
    ("P007", "USB Hub", "Electronics", 420, 620, 15),
    ("P008", "Power Bank", "Electronics", 780, 1150, 12),
    ("P009", "Cordless Drill", "Tools", 2900, 3990, 3),
    ("P010", "Socket Set", "Tools", 950, 1380, 8),
    ("P011", "Measuring Tape", "Tools", 90, 140, 50),
    ("P012", "Pallet Jack", "Tools", 14500, 18900, 1),
    ("P013", "Safety Helmet", "Safety Gear", 210, 320, 60),
    ("P014", "Hi-Vis Vest", "Safety Gear", 120, 185, 80),
    ("P015", "Work Gloves", "Safety Gear", 75, 120, 100),
    ("P016", "Safety Shoes", "Safety Gear", 780, 1150, 30),
    ("P017", "A4 Paper Ream", "Office Supplies", 210, 285, 90),
    ("P018", "Marker Set", "Office Supplies", 60, 95, 70),
    ("P019", "Stapler", "Office Supplies", 85, 130, 45),
    ("P020", "Whiteboard", "Office Supplies", 1150, 1650, 6),
]
PRODUCT_WEIGHTS = np.array([9, 5, 7, 4, 3, 1.5, 6, 5, 2, 4, 6, 0.8,
                            6, 6, 8, 4, 8, 6, 5, 2.5])
PRODUCT_WEIGHTS = PRODUCT_WEIGHTS / PRODUCT_WEIGHTS.sum()

START, END = date(2026, 1, 1), date(2026, 6, 30)
EXPORT_DATE = date(2026, 7, 6)  # orders after this are not yet closed

DATE_FORMATS = ["%Y-%m-%d", "%d/%m/%Y", "%d-%b-%y", "%b %d, %Y"]


# --------------------------------------------------------------------------
# Build the "true" clean orders
# --------------------------------------------------------------------------
def build_true_orders() -> pd.DataFrame:
    days = (END - START).days + 1
    # Demand grows through the half-year
    day_weights = np.linspace(0.8, 1.35, days)
    day_weights = day_weights / day_weights.sum()
    offsets = rng.choice(days, size=N_ORDERS, p=day_weights)
    rows = []
    for i in range(N_ORDERS):
        wh = WAREHOUSES[rng.choice(len(WAREHOUSES), p=WAREHOUSE_WEIGHTS)][1]
        pid, _, _, _, list_price, typical = PRODUCTS[
            rng.choice(len(PRODUCTS), p=PRODUCT_WEIGHTS)]
        qty = max(1, int(rng.poisson(typical)))
        price = round(list_price * rng.uniform(0.92, 1.04), 2)
        order_dt = START + timedelta(days=int(offsets[i]))

        lead = max(1, int(round(rng.normal(LEAD_TIME_MEAN[wh], 1.4))))
        delivery_dt = order_dt + timedelta(days=lead)
        u = rng.random()
        if u < 0.05:
            status, delivery_dt = "Cancelled", None
        elif delivery_dt <= EXPORT_DATE - timedelta(days=3):
            status = "Delivered"
        elif delivery_dt <= EXPORT_DATE:
            status, delivery_dt = "In Transit", None
        else:
            status, delivery_dt = ("Shipped" if u < 0.6 else "Pending"), None
        rows.append({
            "order_id": f"ORD-{10001 + i}", "order_date": order_dt,
            "warehouse": wh, "product_id": pid, "quantity": qty,
            "unit_price": price, "status": status, "delivery_date": delivery_dt,
        })
    return pd.DataFrame(rows).sort_values("order_date").reset_index(drop=True)


# --------------------------------------------------------------------------
# Messy formatting helpers
# --------------------------------------------------------------------------
def fmt_date(d, as_real_date_prob=0.0):
    if d is None or pd.isna(d):
        return None
    if random.random() < as_real_date_prob:
        return datetime(d.year, d.month, d.day)
    return d.strftime(random.choice(DATE_FORMATS))


def messy_orders(df: pd.DataFrame, real_dates=0.0) -> pd.DataFrame:
    out = df.copy()
    status_variants = {
        "Delivered": ["Delivered", "delivered", "DELIVERED", "Delivered "],
        "Cancelled": ["Cancelled", "cancelled", "Canceled"],
        "In Transit": ["In Transit", "in transit", "In-Transit"],
        "Shipped": ["Shipped", "shipped"],
        "Pending": ["Pending", "PENDING", "pending"],
    }
    out["status"] = [random.choice(status_variants[s]) for s in out["status"]]
    out["warehouse"] = [random.choice(WAREHOUSE_ALIASES[w]) for w in out["warehouse"]]
    out["order_id"] = [random.choice([o, o, o, o.lower(), f" {o}"]) for o in out["order_id"]]
    out["product_id"] = [random.choice([p, p, p, p.lower(), f"{p} "]) for p in out["product_id"]]
    out["order_date"] = [fmt_date(d, real_dates) for d in out["order_date"]]
    out["delivery_date"] = [fmt_date(d, real_dates) for d in out["delivery_date"]]

    # numeric noise (stored as object so text can be mixed in)
    qty, price = [], []
    for q, p in zip(out["quantity"], out["unit_price"]):
        r = random.random()
        if r < 0.03:
            q = None                      # missing quantity
        elif r < 0.035:
            q = -q                        # sign error
        elif r < 0.05:
            q = f"{q} pcs"                # text unit
        qty.append(q)
        r = random.random()
        if r < 0.03:
            p = None                      # missing price
        elif r < 0.10:
            p = f"\u20b9{p:,.2f}"         # currency symbol + thousands comma
        price.append(p)
    out["quantity"], out["unit_price"] = qty, price

    # missing warehouse
    out.loc[out.sample(frac=0.02, random_state=SEED).index, "warehouse"] = None

    # a few deliveries dated BEFORE the order (data-entry error)
    delivered = out.index[out["delivery_date"].notna()]
    bad = random.sample(list(delivered), k=max(1, int(0.01 * len(delivered))))
    for i in bad:
        earlier = df.at[i, "order_date"] - timedelta(days=random.randint(1, 4))
        out.at[i, "delivery_date"] = fmt_date(earlier)
    return out, bad


def add_duplicates(df: pd.DataFrame, frac=0.04) -> pd.DataFrame:
    dupes = df.sample(frac=frac, random_state=SEED + 1)
    return pd.concat([df, dupes], ignore_index=True).sample(
        frac=1, random_state=SEED + 2).reset_index(drop=True)


# --------------------------------------------------------------------------
def main():
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    true = build_true_orders()

    # ---- reference files ------------------------------------------------
    pd.DataFrame(WAREHOUSES, columns=["warehouse_id", "warehouse_name", "state"]) \
        .to_csv(RAW_DIR / "warehouses.csv", index=False)

    prod = pd.DataFrame(PRODUCTS, columns=[
        "Product ID", "Product Name", "Category", "Unit Cost", "List Price", "_typ"]).drop(columns="_typ")
    prod["Category"] = [random.choice([c, c, c.lower(), f"{c} "]) for c in prod["Category"]]
    prod["Product Name"] = [f" {n}" if random.random() < 0.15 else n for n in prod["Product Name"]]
    prod = pd.concat([prod, prod.sample(2, random_state=SEED)], ignore_index=True)  # 2 duplicate rows
    prod.to_excel(RAW_DIR / "products.xlsx", index=False, sheet_name="Products")

    # ---- three order exports --------------------------------------------
    q1 = true[true["order_date"] < date(2026, 4, 1)]
    q2 = true[(true["order_date"] >= date(2026, 4, 1))]
    late = q2[q2["order_date"] >= date(2026, 6, 15)].copy()

    m1, _ = messy_orders(q1)
    m1 = add_duplicates(m1)
    m1.columns = ["Order ID", "Order Date", "Warehouse", "Product ID",
                  "Qty", "Unit Price", "Status", "Delivery Date"]
    m1.to_csv(RAW_DIR / "orders_jan_mar.csv", index=False)

    m2, _ = messy_orders(q2)
    m2 = add_duplicates(m2)
    m2.columns = ["order_id", "order_dt", "wh", "product_id",
                  "quantity", "price", "order_status", "delivered_on"]
    m2.to_csv(RAW_DIR / "orders_apr_jun.csv", index=False)

    # Late re-export (Excel): same June orders with refreshed status
    m3, _ = messy_orders(late, real_dates=0.5)
    m3.columns = ["OrderID", "OrderDate", "Warehouse", "ProductID",
                  "Quantity", "UnitPrice", "OrderStatus", "DeliveryDate"]
    m3.to_excel(RAW_DIR / "orders_jun_reexport.xlsx", index=False, sheet_name="Orders")

    print(f"Raw files written to {RAW_DIR}")
    for f in sorted(RAW_DIR.iterdir()):
        print(f"  {f.name}")


if __name__ == "__main__":
    main()
