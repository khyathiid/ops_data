"""
Load the cleaned data into SQLite and run the reporting queries in sql/queries.sql.

Outputs
  data/processed/ops.db                    - SQLite database (orders, products, warehouses)
  reports/sql_results/<query_name>.csv     - one CSV per query

Run:  python src/run_sql.py
"""
import re
import sqlite3
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
RESULTS = ROOT / "reports" / "sql_results"
SQL_FILE = ROOT / "sql" / "queries.sql"


def build_database() -> sqlite3.Connection:
    db_path = PROCESSED / "ops.db"
    if db_path.exists():
        db_path.unlink()
    con = sqlite3.connect(db_path)
    orders = pd.read_csv(PROCESSED / "orders_clean.csv")
    for col in ["qty_imputed", "price_imputed", "delivery_date_invalid"]:
        orders[col] = orders[col].astype(int)  # SQLite has no boolean type
    orders.to_sql("orders", con, index=False)
    pd.read_csv(PROCESSED / "products_clean.csv").to_sql("products", con, index=False)
    pd.read_csv(PROCESSED / "warehouses_clean.csv").to_sql("warehouses", con, index=False)
    con.execute("CREATE INDEX idx_orders_month ON orders(order_month)")
    con.execute("CREATE INDEX idx_orders_wh ON orders(warehouse)")
    con.execute("CREATE INDEX idx_orders_prod ON orders(product_id)")
    return con


def load_queries() -> dict:
    text = SQL_FILE.read_text(encoding="utf-8")
    blocks = re.split(r"^-- name:\s*(\w+)\s*$", text, flags=re.M)
    # blocks = [preamble, name1, sql1, name2, sql2, ...]
    return {blocks[i]: blocks[i + 1].strip() for i in range(1, len(blocks), 2)}


def run_all() -> dict:
    RESULTS.mkdir(parents=True, exist_ok=True)
    con = build_database()
    results = {}
    for name, sql in load_queries().items():
        df = pd.read_sql_query(sql, con)
        df.to_csv(RESULTS / f"{name}.csv", index=False)
        results[name] = df
        print(f"[{name}] {len(df)} rows")
    con.close()
    return results


if __name__ == "__main__":
    for name, df in run_all().items():
        print(f"\n== {name} ==")
        print(df.to_string(index=False))
