-- =====================================================================
-- Operations reporting queries (SQLite)
-- Tables: orders (fact), products (dim), warehouses (dim)
-- Each block starts with "-- name: <query_name>" and is run by src/run_sql.py
-- Revenue is already 0 for cancelled orders; on_time / lead_time_days are NULL
-- when a usable delivery date is not available (AVG / SUM ignore NULLs).
-- =====================================================================

-- name: monthly_summary
-- Orders, revenue and delivery performance by month (cancelled excluded from AOV)
SELECT
    o.order_month,
    COUNT(*)                                                     AS total_orders,
    SUM(CASE WHEN o.status = 'Cancelled' THEN 1 ELSE 0 END)      AS cancelled_orders,
    ROUND(SUM(o.revenue), 2)                                     AS revenue,
    ROUND(SUM(o.revenue) * 1.0
          / NULLIF(SUM(CASE WHEN o.status <> 'Cancelled' THEN 1 ELSE 0 END), 0), 2) AS avg_order_value,
    ROUND(AVG(o.lead_time_days), 2)                              AS avg_lead_time_days,
    ROUND(100.0 * AVG(o.on_time), 1)                             AS on_time_pct
FROM orders AS o
GROUP BY o.order_month
ORDER BY o.order_month;

-- name: warehouse_performance
-- JOIN to the warehouse dimension; LEFT JOIN keeps rows whose warehouse is 'Unknown'
SELECT
    o.warehouse,
    COALESCE(w.state, 'Unknown')                                 AS state,
    COUNT(*)                                                     AS total_orders,
    ROUND(SUM(o.revenue), 2)                                     AS revenue,
    ROUND(AVG(o.lead_time_days), 2)                              AS avg_lead_time_days,
    ROUND(100.0 * AVG(o.on_time), 1)                             AS on_time_pct,
    ROUND(100.0 * SUM(CASE WHEN o.status = 'Cancelled' THEN 1 ELSE 0 END) / COUNT(*), 1) AS cancel_rate_pct
FROM orders AS o
LEFT JOIN warehouses AS w ON w.warehouse_name = o.warehouse
GROUP BY o.warehouse, w.state
ORDER BY revenue DESC;

-- name: top_products
-- Top 10 products by revenue with gross margin (JOIN orders -> products)
SELECT
    p.product_id,
    p.product_name,
    p.category,
    SUM(CASE WHEN o.status <> 'Cancelled' THEN o.quantity ELSE 0 END) AS units_sold,
    ROUND(SUM(o.revenue), 2)                                     AS revenue,
    ROUND(SUM(o.gross_margin), 2)                                AS gross_margin,
    ROUND(100.0 * SUM(o.gross_margin) / NULLIF(SUM(o.revenue), 0), 1) AS margin_pct
FROM orders   AS o
JOIN products AS p ON p.product_id = o.product_id
GROUP BY p.product_id, p.product_name, p.category
ORDER BY revenue DESC
LIMIT 10;

-- name: category_by_state
-- Three-table join: revenue and volume of each category in each state
-- (inner join, so orders with an 'Unknown' warehouse are intentionally excluded here)
SELECT
    p.category,
    w.state,
    COUNT(*)                                                     AS total_orders,
    ROUND(SUM(o.revenue), 2)                                     AS revenue
FROM orders     AS o
JOIN products   AS p ON p.product_id     = o.product_id
JOIN warehouses AS w ON w.warehouse_name = o.warehouse
GROUP BY p.category, w.state
ORDER BY p.category, revenue DESC;

-- name: slow_lanes
-- HAVING: warehouse x category combinations with meaningful volume and the slowest delivery
SELECT
    o.warehouse,
    p.category,
    COUNT(o.lead_time_days)                                      AS delivered_orders,
    ROUND(AVG(o.lead_time_days), 2)                              AS avg_lead_time_days,
    ROUND(100.0 * AVG(o.on_time), 1)                             AS on_time_pct
FROM orders   AS o
JOIN products AS p ON p.product_id = o.product_id
WHERE o.warehouse <> 'Unknown'
GROUP BY o.warehouse, p.category
HAVING COUNT(o.lead_time_days) >= 30
ORDER BY on_time_pct ASC, avg_lead_time_days DESC
LIMIT 8;

-- name: data_quality_by_source
-- How many imputed / invalid records each source file contributed
SELECT
    source_file,
    COUNT(*)                                                     AS orders_kept,
    SUM(qty_imputed)                                             AS qty_imputed,
    SUM(price_imputed)                                           AS price_imputed,
    SUM(delivery_date_invalid)                                   AS bad_delivery_dates
FROM orders
GROUP BY source_file
ORDER BY source_file;
